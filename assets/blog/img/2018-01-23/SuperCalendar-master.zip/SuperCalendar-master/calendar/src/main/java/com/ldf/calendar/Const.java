package com.ldf.calendar;

/**
 * Created by ldf on 17/6/27.
 */

public class Const {
    public final static int TOTAL_COL = 7;
    public final static int TOTAL_ROW = 6;
    public final static int CURRENT_PAGER_INDEX = 1000;
}
